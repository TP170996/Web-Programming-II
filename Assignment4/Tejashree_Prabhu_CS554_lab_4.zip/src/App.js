/*Author:Tejashree Prabhu
  References:Stackoverflow, w3,reactjs.org,CS554 codebase,marvel api*/

import React, {Component} from "react";
import {BrowserRouter as Router,Route,Link,Switch,Redirect} from "react-router-dom";

import IndexCharacters from "./Components/Characters/Index";
import IndexSeries from "./Components/Series/Index";
import IndexComics from "./Components/Comics/Index";
import NotFound from "./Components/NotFound";


import './App.css';

class App extends Component {
  render() {
    return (
      <Router>
        <div className="App">
          <header className="App-header">
            
            <h1 className="App-title">Welcome to Marvel!</h1>
            <h2>Made by Tejashree Prabhu</h2>
            <p>References: stackoverflow, w3,reactjs.org,CS554 codebase, marvel api</p>
            <p>The Marvel Comics API allows developers everywhere to access information about Marvel's vast library of comics—from what's coming up, to 70 years ago.</p>
            
            <ul>
        
        <li><Link to={"/characters/page/0"}>Characters</Link></li>
        <li><Link to={"/comics/page/0"}>Comics</Link></li>
        <li><Link to={"/series/page/0"}>Series</Link></li>
      </ul>
          </header>
          <br />
          <br />
          <div className="App-body">
            
            <Route path="/characters/"  component={IndexCharacters} />
            <Route path="/series/"  component={IndexSeries} />
            <Route path="/comics/"  component={IndexComics} />
            <Route path="/404" component={NotFound} />        
       
           
          </div>
          <br />
        </div>
      </Router>
    );
  }
}

export default App;
