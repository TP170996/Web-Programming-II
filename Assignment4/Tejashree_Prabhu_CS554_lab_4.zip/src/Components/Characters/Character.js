import React, { Component } from "react";
import axios from 'axios';
import { Redirect, Link } from 'react-router-dom';
import NotFound from "../NotFound"


const md5 = require('blueimp-md5');
const publickey = '2f2df946f6f166236bdff6e4d69f7844';
const privatekey = '7195533bf0ee3ad7531d7d61c9bf540c81e8b4db';
const ts = new Date().getTime();
const stringToHash = ts + privatekey + publickey;
const hash = md5(stringToHash);
const baseUrl = 'https://gateway.marvel.com:443/v1/public/characters';
const url =  '?ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;

class Character extends Component {
    constructor(props) {
       super(props);
       this.state = {
          data: undefined,
          error: false
       };
    }
    componentDidMount() {
       this.getCharacterData();
    }
    async getCharacterData() {
       
       try {
          const response = await axios.get(
             `${baseUrl}/${this.props.match.params.id}${url}`
              );
              
          this.setState({
             data: response.data.data.results
          });
        
       } catch (e) {
           this.setState({
               error: true
           });
          console.log(`error ${e}`);
       }
    }
    render() {
       let Character_data =
       this.state.data &&
       this.state.data.map(re => (
           <div>
           <p>Character Name: {re.name}</p>
           <p>Character ID: {re.id}</p>
           <p>Description: {re.description}</p>
           </div>
       ));

         if (this.state.error) {
            return <NotFound/>
         }         
        else {
          
          return(
              <div className="detail">
              {Character_data}
              </div>
          )
          
    }
 }
}
 
 export default Character;
 