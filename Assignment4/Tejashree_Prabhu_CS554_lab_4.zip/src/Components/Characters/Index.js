import React from "react";
import {BrowserRouter as Router,Route,Link,Switch,Redirect} from "react-router-dom";

import ListofCharacters from "./ListofCharacters";
import Character from "./Character";
import NotFound from "../NotFound";






function IndexCharacters() {
          
      
 
    return (
        <div>
      <Router> 
      <Switch>
      <Route path="/characters/page/:page"   component={ListofCharacters} />      
      <Route path={`/character/:id`} component={Character} /> 
      <Route component={NotFound} />  
      
      </Switch>
      </Router> 
        
        </div>

        
    );}

export default IndexCharacters;