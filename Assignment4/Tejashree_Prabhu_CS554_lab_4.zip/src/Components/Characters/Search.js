import React,  { useState, useEffect } from "react";
import ReactDOM from "react-dom";
import {Link} from 'react-router-dom';
import axios from "axios";


const md5 = require('blueimp-md5');
const publickey = '2f2df946f6f166236bdff6e4d69f7844';
const privatekey = '7195533bf0ee3ad7531d7d61c9bf540c81e8b4db';
const ts = new Date().getTime();
const stringToHash = ts + privatekey + publickey;
const hash = md5(stringToHash);
const baseUrl = 'https://gateway.marvel.com:443/v1/public/characters';
const url = baseUrl + '?ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;


function Search() {
    let name=[];
    let id=[];
    let list1=[];
    let list2=[];
    const [searchTerm, setSearchTerm] = React.useState("");
    const [searchResults, setSearchResults] = React.useState([]);
    const [characters, setCharacters] = React.useState([]);
    
  
    
    const handleChange = e => {
      setSearchTerm(e.target.value);
    };
    React.useEffect(() => {
        async function getCharactersData() {               
                const response = await axios.get(`${url}&limit=100`);                
                setCharacters(response.data.data.results)                
            }      
        getCharactersData();

        characters.map(re=>{
            name.push(re.name);
            id.push(re.id);
        })
        for(let i=0;i<name.length;i++)
        {
            list1.push({name:name[i],id:id[i]})
        }
        const results = name.filter(re =>
            re.toLowerCase().includes(searchTerm.toLowerCase())
          );
          for(let i=0;i<results.length;i++)
        {
        for(let j=0;j<list1.length;j++)
        {
            if(list1[j].name===results[i])
            {
                list2.push(list1[j])
            }

        }
          
        }
        setSearchResults(list2);
        
    
    }, [searchTerm]);

    return(

        <div>
        <label for="my-input" className="myinput">Search</label><br/><br/>
        <input
        type="text"
        placeholder="Search Characters"
        value={searchTerm}
        className="searchInput"
        onChange={handleChange}
      />
      
        {searchResults.map(re => (
          <div>
          <Link to={`/characters/${re.id}`} style={{ textDecoration: 'none' }}>  
            
            <p className="searchResult">{re.name}</p>
          </Link>
          
          </div>  
          
        ))}
        
        </div>
    );

}
export default Search;