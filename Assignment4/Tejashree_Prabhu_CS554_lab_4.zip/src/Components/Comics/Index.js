import React from "react";
import {BrowserRouter as Router,Route,Link,Switch,Redirect} from "react-router-dom";

import ListofComics from "./ListofComics";
import Comics from "./Comics";
import NotFound from "../NotFound";






function IndexSeries() {
          
      
 
    return (
        <div>
      <Router> 
      <Switch>
      <Route path="/comics/page/:page"   component={ListofComics} />      
      <Route path={`/comics/:id`} component={Comics} /> 
      <Route component={NotFound} />  
      
      </Switch>
      </Router> 
        
        </div>

        
    );}

export default IndexSeries;