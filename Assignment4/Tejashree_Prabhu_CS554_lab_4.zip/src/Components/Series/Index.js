import React from "react";
import {BrowserRouter as Router,Route,Link,Switch,Redirect} from "react-router-dom";

import ListofSeries from "./ListofSeries";
import Series from "./Series";
import NotFound from "../NotFound";






function IndexSeries() {
          
      
 
    return (
        <div>
      <Router> 
      <Switch>
      <Route path="/series/page/:page"   component={ListofSeries} />      
      <Route path={`/series/:id`} component={Series} /> 
      <Route component={NotFound} />  
      
      </Switch>
      </Router> 
        
        </div>

        
    );}

export default IndexSeries;