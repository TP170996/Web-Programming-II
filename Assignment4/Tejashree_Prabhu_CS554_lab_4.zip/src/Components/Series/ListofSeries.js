import React, { Component } from 'react';
import {Link} from "react-router-dom";

import NotFound from "../NotFound";
import axios from 'axios';
import Pagination from 'react-bootstrap/Pagination';
import Search from "./Search";


const md5 = require('blueimp-md5');
const publickey = '2f2df946f6f166236bdff6e4d69f7844';
const privatekey = '7195533bf0ee3ad7531d7d61c9bf540c81e8b4db';
const ts = new Date().getTime();
const stringToHash = ts + privatekey + publickey;
const hash = md5(stringToHash);
const baseUrl = 'https://gateway.marvel.com:443/v1/public/series';
const url = baseUrl + '?ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;




class ListofSeries extends Component {
	
	constructor(props) {
		super(props);
		this.state = {
			data: undefined,
			page: 0,
			total: undefined,
			last_page: 0,
			error: false
		};
		this.previousPage = this.previousPage.bind(this, this.state.page);
		this.nextPage = this.nextPage.bind(this, this.state.page);
		}

	
	async getSeriesData() {
		try {
			let page = Number(this.state.page);
            const response = await axios.get(`${url}&offset=${page * 20}`);
            
			this.setState({
				data: response.data.data.results,
				total: response.data.data.total,
				last_page: Math.floor(this.state.total/20)
			});
		} catch (e) {
			this.setState({
				error: true
			});
			console.log(e);
		}
	}
    
	componentDidMount() {
		const { page } = this.props.match.params;
		this.setState({page: page}, () => {
			this.getSeriesData();
		});
	}
   //Used Stackoverflow for refererence for the following logic
	previousPage() {
		let page = Number(this.state.page);
		if (page > 0) {
			this.setState({ page: page - 1 }, () => {
				this.getSeriesData();
				this.props.history.push(`/series/page/${this.state.page}`);
			});
		}
	}

	nextPage() {
		let page = Number(this.state.page);
		if (this.state.last_page - this.state.page === 0) {
			this.setState({
				error: true
			});
		} else {
			this.setState({ page: page + 1 }, () => {
				this.getSeriesData();
				this.props.history.push(`/series/page/${this.state.page}`);
			});
		}
	}

	render() {
		let series_data =
			this.state.data &&
			this.state.data.map(re => (
				<p key={re.title}>
					<Link to={`/series/${re.id}`}>{re.title}</Link>
				</p>
			));

		if (Number(this.state.page)-1  >= this.state.last_page || this.state.error===true) {
			return <NotFound/>
		}
        //used https://react-bootstrap.github.io/components/pagination/ for reference 
		let pagination = null;
		if (Number(this.state.page) === 0) { 
			pagination = <Pagination>
				<Pagination.Next onClick={this.nextPage}></Pagination.Next>
			</Pagination>
		}
		else if(Number(this.state.page)===this.state.last_page)
			{
				pagination = <Pagination>
				<Pagination.Prev onClick={this.previousPage}></Pagination.Prev>
			    </Pagination>
              

			}
		
		else {
			pagination = <Pagination>
					<Pagination.Prev onClick={this.previousPage}></Pagination.Prev>
					<Pagination.Next onClick={this.nextPage}></Pagination.Next>
				</Pagination>
		}
		

		return(
            <div className="charList">
			<div className="row">
			<div className="col left">
			<div className="pagination">{pagination}</div>
				<h2>Series</h2>
				<p>{series_data}</p>
			</div>
			<div className="col right">
			<Search/>
			</div>
			</div>
			
				
			</div>
		);
	
	}
}

export default ListofSeries;
