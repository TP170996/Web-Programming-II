import React from 'react';
import './App.css';
import MyPosts from './MyPosts';
import NewPost from './NewPost';
import Images from './Images';
import { BrowserRouter as Router, Route, Redirect, Link, nav, NavLink} from "react-router-dom";
import Binned from './Binned';
import 'bootstrap/dist/css/bootstrap.min.css';


function App(){
return(
  <Router>
  <nav className="navigationbar">
  <NavLink class="navigation"  to="/my-bin">My Bin</NavLink>
  <NavLink class="navigation" to="/">Images</NavLink>
  <NavLink class="navigation" to="/my-posts">My Posts</NavLink>

  </nav>
 
  <Route path="/my-bin" exact component={Binned}></Route>  
  <Route path="/" exact component={Images}></Route>  
  <Route path="/my-posts" component={MyPosts}></Route>
  <Route path="/new-post" component={NewPost}></Route>
  
  </Router>
);
 
}

export default App;