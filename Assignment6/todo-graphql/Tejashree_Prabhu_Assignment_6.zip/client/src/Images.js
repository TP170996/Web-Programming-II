import React from 'react';
import './App.css';
import { useQuery, useMutation } from '@apollo/react-hooks';
import gql from "graphql-tag";
import { Link} from "react-router-dom";
import Card from 'react-bootstrap/Card'

const READ_IMAGES = gql`
  query unsplashImages{
    unsplashImages {
      id
      url
      
    }
  }
`;


const UPDATE_IMAGE = gql`
  mutation addToBin($id:String! $url:String!) {
    addToBin(id:$id url:$url)
  }
`;



function Images() {

  const { data, loading, error } = useQuery(READ_IMAGES);


const [addToBin] = useMutation(UPDATE_IMAGE);

  if (loading) return <p>loading...</p>;
  if (error) return <p>ERROR</p>;
  if (!data) return <p>Not found</p>;

  return (
    <div className="app">
      
      
    
      <ul>
        {data.unsplashImages.map((i) =>
          <li key={i.id}>
          <Card style={{ width: '18rem' }}>
          <Card.Img variant="top" src={i.url} />
          <Card.Body>
           
            
            <button className={ " btn btn-sm btn-danger float-left"} onClick={() => {
              addToBin({ variables: { id: i.id ,url:i.url } });
              window.location.reload();
              
            }}>{i.binned ?<p>remove from bin</p>:<p>bin</p> }</button>  
            </Card.Body>
            </Card> 
                 
          </li>
        )}
      </ul>
    </div>
  );
}

export default Images;
