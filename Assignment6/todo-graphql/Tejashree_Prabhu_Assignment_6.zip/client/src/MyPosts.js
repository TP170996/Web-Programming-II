import React from 'react';
import './App.css';
import { useQuery, useMutation } from '@apollo/react-hooks';
import gql from "graphql-tag";
import { Link} from "react-router-dom";
import Card from 'react-bootstrap/Card'

const READ_IMAGES = gql`
  query userPostedImages{
    userPostedImages {
      id
      url
     
      userPosted
      binned
    }
  }
`;


const UPDATE_IMAGE = gql`
  mutation UpdateImage($id:String! ) {
    updateImage(id:$id )
  }
`;

const DELETE_IMAGE = gql`
  mutation DeleteImage($id: String!) {
    deleteImage(id: $id)
  }

`;

function MyPosts() {

const { data, loading, error } = useQuery(READ_IMAGES);

const [deleteImage] = useMutation(DELETE_IMAGE);
const [updateImage] = useMutation(UPDATE_IMAGE);

  if (loading) return <p>loading...</p>;
  if (error) return <p>ERROR</p>;
  if (!data) return <p>Not found</p>;

  return (
    <div className="app">
      <Link to="/new-post" className="posttitle">Upload a Post</Link>
      
    
      <ul>
        {data.userPostedImages.map((i) =>
          <li key={i.id}>
          <Card style={{ width: '18rem' }}>
          <Card.Img variant="top" src={i.url} />
          <Card.Body>
            
            
            <button className={ " btn btn-sm btn-danger  float-right"} onClick={() => {
              deleteImage({ variables: { id: i.id } });
              window.location.reload();
            }}>Delete</button>  
            <button className={ " btn btn-sm btn-danger float-left"} onClick={() => {
              updateImage({ variables: { id: i.id } });
              window.location.reload();
            }}>{i.binned ?<p>remove from bin</p>:<p>bin</p> }</button>  
            </Card.Body>
            </Card> 
                 
          </li>
        )}
      </ul>
    </div>
  );
}

export default MyPosts;
