import React from 'react';
import './App.css';
import { useQuery, useMutation } from '@apollo/react-hooks';
import gql from "graphql-tag";


const UPLOAD_IMAGE = gql`
  mutation UploadImage($url: String!) {
    uploadImage(url: $url)
  }
`;


function MyPosts() {

  let input1;
  let input2;
  let input3;

const [uploadImage] = useMutation(UPLOAD_IMAGE);

  return (
    <div className="app">
      
      <form onSubmit={e => {
        e.preventDefault();
        uploadImage({ variables: { url: input1.value, posterName:input2.value, description:input3.value } });
      
        window.location.reload();
    }}>
    <input className="form-control" type="text" placeholder="Enter image url" ref={node => { input1 = node; }}></input>
    <input className="form-control" type="text" placeholder="Enter poster name" ref={node => { input2 = node; }}></input>
    <input className="form-control" type="text" placeholder="Enter description" ref={node => { input3 = node; }}></input>
    <button className="btn btn-primary px-5 my-2" type="submit">Submit</button>
      </form>
    
    </div>
  );
}

export default MyPosts;
